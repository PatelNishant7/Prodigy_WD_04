function generatecv() {


let nameField = document.getElementById("nameField").value;
let nameT1=document.getElementById("nameT1");
nameT1.innerHTML = nameField;

document.getElementById('nameT2').innerHTML=nameField
    
let phoneField = document.getElementById("phoneField").value;
let phoneT=document.getElementById("phoneT");
phoneT.innerHTML = phoneField;

let addressField = document.getElementById("addressField").value;
let addressT=document.getElementById("addressT");
addressT.innerHTML = addressField;

let skillField = document.getElementById("skillField").value;
let skillT=document.getElementById("skillT");
skillT.innerHTML = skillField;

let objField = document.getElementById("objField").value;
let objT=document.getElementById("objT");
objT.innerHTML = objField;

let expField = document.getElementById("expField").value;
let expT=document.getElementById("expT");
expT.innerHTML = expField;

let eduField = document.getElementById("eduField").value;
let eduT=document.getElementById("eduT");
eduT.innerHTML = eduField;

document.getElementById('cv-form').style.display='none';
document.getElementById('cv-template').style.display='block';

}

// function addNewWorkExp() {
//     // console.log("hello world");
// let newNode=document.createElement('textarea');
// newNode.classList.add('form-group');
// newNode.classList.add('WEfield');
// newNode.setAttribute('placeholder','enter here')
// newNode.setAttribute("row",2);

// let WEOB=document.getElementById('WE');
// let  weaddbuttonOB = document.getElementById("weaddbutton");

// WEOB.insertBefore(newNode, weaddbuttonOB);
// }


// function addNewEdu() {
//     // console.log("hello world");
// let newNode=document.createElement('textarea');
// newNode.classList.add('form-group');
// newNode.classList.add('EDfield');
// newNode.setAttribute('placeholder','enter here')
// newNode.setAttribute("row",2);

// let EDOB=document.getElementById('ED');
// let  aduaddbuttonOB = document.getElementById("aduaddbutton");

// EDOB.insertBefore(newNode, aduaddbuttonOB);
// }


